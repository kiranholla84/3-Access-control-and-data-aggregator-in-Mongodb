# Imports MongoClient for base level access to the local MongoDB
from pymongo import MongoClient
from bson.objectid import ObjectId

class Database:
    # Class static variables used for database host ip and port information, database name
    # Static variables are referred to by using <class_name>.<variable_name>
    HOST = '127.0.0.1'
    PORT = '27017'
    DB_NAME = 'weather_db'

    def __init__(self, requesting_user):
        self._db_conn = MongoClient(f'mongodb://{Database.HOST}:{Database.PORT}')
        self._db = self._db_conn[Database.DB_NAME]
        self.requesting_user = requesting_user

    # This method finds a single document using field information provided in the key parameter
    # It assumes that the key returns a unique document. It returns None if no document is found
    def get_single_data(self, collection, key):

        # Check for permission to read device or weather data
        if collection == 'users':
            self.permission = self.return_user_permission_info()
        elif collection == "devices":
            self.permission = self.return_device_permission_info(key, "read")
        elif collection == 'weather_data':
            self.permission = self.return_weatherdata_permission_info(key, "read")
        else:
            pass

        if self.permission != -1:
            # case of device or user or weather data not found
            if self.permission == "":
                return ""
            db_collection = self._db[collection]
            document = db_collection.find_one(key)
            return document
        else:
            return -1

    # This method finds a single document using field information provided in the key parameter
    # It assumes that the key returns a unique document. It returns None if no document is found
    def get_all_data(self, collection, key):

        self.permission = self.return_device_permission_info(key, "read")

        if self.permission != -1:
            db_collection = self._db[collection]
            list_data_deviceId = db_collection.find(key)
            return list_data_deviceId
        else:
            return -1

    def distinct_data(self, collection, field_requested):

        self.permission = self.return_weatherdata_permission_info(field_requested, "read")

        if self.permission != -1:
            db_collection = self._db[collection]
            _distinct_values = db_collection.distinct(field_requested)
            return _distinct_values
        else:
            return -1

    def aggregate_data(self, collection, key):

        self.permission = self.return_device_permission_info(key, "read")

        if self.permission != -1:
            db_collection = self._db[collection]
            if self.permission != "":
                list_dateValue_deviceId = list(db_collection.aggregate([{'$match': key}]))
                return list_dateValue_deviceId
            else:
                print("This user does not have access to device")
                return -1
        else:
            return -1

    def list_collection_names_in_db(self):
        db_collection = self._db.list_collection_names()
        return db_collection

    # This method inserts the data in a new document. It assumes that any uniqueness check is done by the caller
    def insert_single_data(self, collection, data):

        if collection == 'users':
            self.permission = self.return_user_permission_info()
        elif collection == "devices":
            self.permission = self.return_device_permission_info(data, "insert")
        elif collection == "weather_data":
            self.permission = self.return_weatherdata_permission_info(data, "insert")
        else:
            self.permission = 1

        if self.permission != -1:
            db_collection = self._db[collection]
            document = db_collection.insert_one(data)
            return document.inserted_id
        else:
            return -1

    def update_single_data(self, collection, data_orig, data_replacement):

        data = data_orig

        if collection == 'users':
            self.permission = self.return_user_permission_info()
        elif collection == "devices":
            self.permission = self.return_device_permission_info(data, "update")
        elif collection == "weather_data":
            self.permission = self.return_weatherdata_permission_info(data, "update")
        else:
            pass

        if self.permission != -1:
            db_collection = self._db[collection]
            updated_data_operation = db_collection.update_one(data_orig, data_replacement)
            return updated_data_operation
        else:
            return -1

    def return_device_permission_info(self, requested_object, requested_operation):

        requesting_username_role = self.get_user_role()
        if requesting_username_role != 'admin':

            if requested_operation == "insert":
                print("User not permitted to perform insert into device db!")
                return -1

            db_collection = self._db['users']
            document = db_collection.find_one({'username': self.requesting_user})

            # below two are for find ops : when device id is given and when object id is given
            if '_id' in requested_object:
                db_collection = self._db['devices']
                requested_device = db_collection.find_one({'_id': ObjectId(requested_object)})['device_id']

            if 'device_id' in requested_object:
                requested_device = requested_object['device_id']

            allowed_access_level = ""
            for element in document['access_list']:
                if element['did'] == requested_device:
                    allowed_access_level = element['atype']

            if allowed_access_level == 'r' and (requested_operation == 'update'):
                print("This operation is not allowed for the user on this device")
                return -1
            else:
                return allowed_access_level

    def return_weatherdata_permission_info(self, requested_object, requested_operation):

        requesting_username_role = self.get_user_role()
        if requesting_username_role != 'admin':
            db_collection = self._db['users']
            document = db_collection.find_one({'username': self.requesting_user})

            # below two are for find ops : when device id is given and when object id is given
            if '_id' in requested_object:
                db_collection = self._db['weather_data']
                requested_object_from_db = db_collection.find_one(requested_object)
                # if requested_object_from_db != None:
                if requested_object_from_db is not None:
                    requested_device = db_collection.find_one(requested_object)['device_id']
                else:
                    return None

            if 'device_id' in requested_object:
                requested_device = requested_object['device_id']

            allowed_access_level = ""
            for element in document['access_list']:
                if element['did'] == requested_device:
                    allowed_access_level = element['atype']

            if allowed_access_level == 'r' and (requested_operation == 'update' or requested_operation == 'insert'):
                print("This operation is not allowed for the user on this device")
                return -1
            else:
                return allowed_access_level

    def return_user_permission_info(self):

        requesting_username_role = self.get_user_role()

        if requesting_username_role != 'admin':
            print("You do not have permission to view/access/modify user collection")
            return -1

    def get_user_role(self):
        # Please note: I have not handled for users not existing in the users list
        db_collection = self._db['users']
        assigned_role = db_collection.find_one({'username': self.requesting_user})['role']
        return assigned_role
