# Imports Database class from the project to provide basic functionality for database access
from database import Database
# Imports ObjectId to convert to the correct format before querying in the db
from bson.objectid import ObjectId
from datetime import date, timedelta
from statistics import mean

# User document contains username (String), email (String), and role (String) fields
class UserModel:
    USER_COLLECTION = 'users'

    def __init__(self, requesting_user):
        self.requesting_user = requesting_user
        self._db = Database(self.requesting_user)
        self._latest_error = ''
    
    # Latest error is used to store the error string in case an issue. It's reset at the beginning of a new function
    #  call
    @property
    def latest_error(self):
        return self._latest_error
    
    # Since username should be unique in users collection, this provides a way to fetch the user document based on
    # the username
    def find_by_username(self, username):
        key = {'username': username}
        return self.__find(key)
    
    # Finds a document based on the unique auto-generated MongoDB object id 
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self.__find(key)
    
    # Private function (starting with __) to be used as the base for all find functions
    def __find(self, key):
        user_document = self._db.get_single_data(UserModel.USER_COLLECTION, key)
        return user_document
    
    # This first checks if a user already exists with that username. If it does, it populates latest_error and
    # returns -1
    # If a user doesn't already exist, it'll insert a new document and return the same to the caller
    def insert_doc_into_user_coll(self, username, email, role):

        self._latest_error = ''
        user_document = self.find_by_username(username)
        if user_document == -1:
            self._latest_error = 'Operation not permitted'
            return -1
        elif user_document:
            self._latest_error = f'Username {username} already exists'
            return -1
        
        user_data = {'username': username, 'email': email, 'role': role}
        user_obj_id = self._db.insert_single_data(UserModel.USER_COLLECTION, user_data)
        return self.find_by_object_id(user_obj_id)


class DeviceModel:
    DEVICE_COLLECTION = 'devices'

    def __init__(self, requesting_user):
        self.requesting_user = requesting_user
        self._db = Database(self.requesting_user)
        self._latest_error = ''
    
    # Latest error is used to store the error string in case an issue. It's reset at the beginning of a new
    # function call
    @property
    def latest_error(self):
        return self._latest_error
    
    # Since device id should be unique in devices collection, this provides a way to fetch the device document
    # based on the device id
    def find_by_device_id(self, device_id):
        key = {'device_id': device_id}
        return self.__find(key)
    
    # Finds a document based on the unique auto-generated MongoDB object id 
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self.__find(key)
    
    # Private function (starting with __) to be used as the base for all find functions
    def __find(self, key,):
        device_document = self._db.get_single_data(DeviceModel.DEVICE_COLLECTION, key)
        return device_document

    def update_device(self, data_for_reference, data_to_be_updated, new_data):
        self._latest_error = ''

        # collecting all user inputs in dictionaries
        for key, value in data_for_reference.items():
            key_data_for_reference = key
            device_id = value_data_for_reference = value

        for key, value in data_to_be_updated.items():
            key_data_to_be_updated = key
            value_data_to_be_updated = value

        for key, value in new_data.items():
            value_updated_data = value

        device_query_output = self.find_by_device_id(value_data_for_reference)

        if device_query_output == -1:
            self._latest_error = f'Operation on {device_id} not permitted'
            return -1
        elif device_query_output != -1:
            # Building dictionaries for sending to the mongodb update
            data_for_update_operation_original = {key_data_for_reference: value_data_for_reference,
                                                  key_data_to_be_updated: value_data_to_be_updated}
            data_for_update_operation_replacement = {"$set": {key_data_to_be_updated: value_updated_data}}

            update_operation_dict = self._db.update_single_data(DeviceModel.DEVICE_COLLECTION,
                                                                data_for_update_operation_original,
                                                                data_for_update_operation_replacement)
            # Update too checks permission - this piece of code will not execute AFAIK
            if update_operation_dict == -1:
                self._latest_error = f'Operation on {device_id} not permitted.'
                return -1
            # If update is successful search for
            elif update_operation_dict.raw_result['updatedExisting'] == True:
                device_query_output_updated = self.find_by_device_id(value_data_for_reference)
                if device_query_output_updated[key_data_to_be_updated] == value_updated_data:
                    return device_query_output_updated
                else:
                    self._latest_error = f'Some failure even though update showed success'
                    return -1
            else:
                self._latest_error = f'Some issue with update, may be the data was already updated or the original ' \
                                     f'data may be invalid.'
                return -1
        else:
            self._latest_error = f'No result. Mostly user does not have this device {device_id} in his access list'
            return -1

    # This first checks if a device already exists with that device id. If it does, it populates latest_error and
    # returns -1
    # If a device doesn't already exist, it'll insert a new document and return the same to the caller
    def insert_doc_into_dev_coll(self, device_id, desc, dev_type, manufacturer):
        self._latest_error = ''
        device_query_output = self.find_by_device_id(device_id)
        if device_query_output == -1:
            self._latest_error = f'Operation on {device_id} not permitted'
            return -1
        elif device_query_output:
            self._latest_error = f'Device id {device_id} already exists'
            return -1
        else:
            device_data = {'device_id': device_id, 'desc': desc, 'type': dev_type, 'manufacturer': manufacturer}
            device_obj_id = self._db.insert_single_data(DeviceModel.DEVICE_COLLECTION, device_data)
            if device_obj_id == -1:
                self._latest_error = f'Unable to create {device_id} document'
                return -1
            else:
                return self.find_by_object_id(device_obj_id)


# Weather data document contains device_id (String), value (Integer), and timestamp (Date) fields
class WeatherDataModel:
    WEATHER_DATA_COLLECTION = 'weather_data'

    def __init__(self, requesting_user):
        self.requesting_user = requesting_user
        self._db = Database(self.requesting_user)
        self._latest_error = ''
    
    # Latest error is used to store the error string in case an issue. It's reset at the beginning of a new function
    # call
    @property
    def latest_error(self):
        return self._latest_error
    
    # Since device id and timestamp should be unique in weather_data collection, this provides a way to fetch the data
    # document based on the device id and timestamp
    def find_by_device_id_and_timestamp(self, device_id, timestamp):
        key = {'device_id': device_id, 'timestamp': timestamp}
        return self.__find(key)
    
    # Finds a document based on the unique auto-generated MongoDB object id 
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self.__find(key)
    
    # Private function (starting with __) to be used as the base for all find functions
    def __find(self, key):
        wdata_document = self._db.get_single_data(WeatherDataModel.WEATHER_DATA_COLLECTION, key)
        return wdata_document

    def update_weatherdata(self, data_for_reference, new_data):
        self._latest_error = ''

        # Getting all user inputs to build dictionaries to send to mongodb update
        for key, value in data_for_reference.items():
            key_data_for_reference = key
            obj_id = value

        for key, value in new_data.items():
            key_new_data = key
            value_new_data = value

        object_query_output = self.find_by_object_id(obj_id)

        if object_query_output == -1:
            self._latest_error = f'Operation on {obj_id} not permitted!'
            return -1

        elif object_query_output is not None:
            # below two variabes will be fed into the mongodb update
            data_for_update_operation_original = {key_data_for_reference: ObjectId(obj_id)}
            data_for_update_operation_replacement = {"$set": {key_new_data: value_new_data}}


            update_operation_dict = \
                self._db.update_single_data(WeatherDataModel.WEATHER_DATA_COLLECTION,
                                            data_for_update_operation_original,
                                            data_for_update_operation_replacement)
            if update_operation_dict == -1:
                self._latest_error = f'Operation on {obj_id} not permitted.'
                return -1
            # search for the updated data
            elif update_operation_dict.raw_result['updatedExisting'] == True:
                device_query_output_updated = self.find_by_object_id(obj_id)
                if device_query_output_updated[key_new_data] == value_new_data:
                    return device_query_output_updated
                else:
                    self._latest_error = f'Some failure even though update showed success'
                    return -1
            else:
                self._latest_error = f'Some issue with update'
                return -1
        else:
            self._latest_error = f'No result obtained. Mostly this object {obj_id} does not exist'
            return -1

    # This first checks if a data item already exists at a particular timestamp for a device id. If it does,
    # it populates latest_error and returns -1.
    # If it doesn't already exist, it'll insert a new document and return the same to the caller
    def insert_doc_into_weatherdata_coll(self, device_id, value, timestamp):
        self._latest_error = ''
        wdata_query_output = self.find_by_device_id_and_timestamp(device_id, timestamp)

        if wdata_query_output == -1:
            self._latest_error = f'Operation on {device_id} not permitted'
            return -1
        elif wdata_query_output:
            self._latest_error = f'Data for timestamp {timestamp} for device id {device_id} already exists'
            return -1
        else:
            date_of_timestamp = (timestamp.strftime('%Y-%m-%d::%H-%M')).split('::')[0]
            weather_data = {'device_id': device_id, 'value': value, 'timestamp': timestamp, 'date' : date_of_timestamp}
            wdata_obj_id = self._db.insert_single_data(WeatherDataModel.WEATHER_DATA_COLLECTION, weather_data)
            if wdata_obj_id == -1:
                return -1
            else:
                return self.find_by_object_id(wdata_obj_id)

    def list_distinct(self, field_to_be_queried):
        self._latest_error = ''
        distinct_values = self._db.distinct_data(WeatherDataModel.WEATHER_DATA_COLLECTION, field_to_be_queried)
        return distinct_values
    
    def get_all_data_deviceId(self, field):
        document_entries= self._db.get_all_data(WeatherDataModel.WEATHER_DATA_COLLECTION, field)
        return document_entries
        

class DailyReportModel:
    REPORTS_COLLECTION = 'daily_reports'

    def __init__(self, requesting_user):
        self.requesting_user = requesting_user
        self._db = Database(self.requesting_user)
        self._latest_error = ''

    # Latest error is used to store the error string in case an issue. It's reset at the beginning of a new
    # function call
    @property
    def latest_error(self):
        return self._latest_error

    # Get unique values of devices. Making use of distinct of mongodb
    def get_distinct_devices(self, field):
        distinct_values = WeatherDataModel.list_distinct(self, field)
        return distinct_values

    def get_documents_deviceId_WeatherData(self, key):
        all_docs_of_devId = WeatherDataModel.get_all_data_deviceId(self, key)
        return all_docs_of_devId

    # aggregator function to insert into daily reports collection
    def insert_data_into_daily_reports_collection(self):

        # Listing all devices in weather_db
        _list_of_all_devices = self.get_distinct_devices("device_id")

        for deviceId in _list_of_all_devices:
            key = {'device_id': deviceId}
            list_deviceId = list(self.get_documents_deviceId_WeatherData(key))

            # List of dates for the device
            list_dates_deviceId = [list_deviceId[devIdIndex]['date'] for devIdIndex in range(len(list_deviceId))]

            # Lists out unique dates by removing all duplicate instances
            list_dates_deviceId_uniq = list(set(list_dates_deviceId))

            # below will match and collect the db entries that match with device id and date. Purpose is to
            # aggregate the data and put that into the daily reports collection
            for dateValue in list_dates_deviceId_uniq:

                key_deviceid_date = {'device_id': deviceId, 'date': dateValue}
                list_dateValue_deviceId = self._db.aggregate_data(WeatherDataModel.WEATHER_DATA_COLLECTION,
                                                                  key_deviceid_date)

                # this will be an array of temperature or humidity values only - 24 values
                list_date_device_TempOrHumidity = [list_dateValue_deviceId[devDateIndex]['value'] for devDateIndex in
                                                   range(len(list_dateValue_deviceId))]

                # Obtain average, min and max from the array
                minValue = min(list_date_device_TempOrHumidity)
                maxValue = max(list_date_device_TempOrHumidity)
                avgValue = round(mean(list_date_device_TempOrHumidity),2)
                daily_report_data = {'date': dateValue, 'device_id': deviceId, 'minimum': minValue, 'maximum': maxValue,
                                     'average': avgValue}

                report_data_obj_id = self._db.insert_single_data(DailyReportModel.REPORTS_COLLECTION, daily_report_data)

                if report_data_obj_id == -1:
                    print("Unable to insert data %s into collection" %daily_report_data)
                else:
                    print("Inserted", report_data_obj_id , "and daily data", daily_report_data, "in"
                          ,DailyReportModel.REPORTS_COLLECTION, "database")

    def get_aggregate_date(self, collection, key_devid_date):
        aggregate_return = self._db.aggregate_data(collection, key_devid_date)
        return aggregate_return


    def get_reports_between_dates(self, device_id, start_date, end_date):
        list_reports = []
        (number_of_days_requested, list_of_dates) = display_dates_given_range(start_date, end_date)

        for dateValue in list_of_dates:
            key_deviceid_date = {'device_id': device_id, 'date': dateValue}
            aggregate_return = self.get_aggregate_date(DailyReportModel.REPORTS_COLLECTION , key_deviceid_date)
            if aggregate_return != -1:
                list_reports.append(aggregate_return)
            else:
                self._latest_error = f'The user may not have permission to access the device or device may not exist'
                return -1

        return list_reports

    def list_collection_names(self):
        db_collection = self._db.list_collection_names_in_db()
        return db_collection


def display_dates_given_range(start_date, end_date):
    dates_requested_for_data = []
    start_date = list(map(int, start_date.split("-")[::-1]))
    start_date = tuple(list(map(int, start_date)))
    start_date = date(start_date[0], start_date[1], start_date[2])  # start date

    end_date = list(map(int, end_date.split("-")[::-1]))
    end_date = tuple(list(map(int, end_date)))
    end_date = date(end_date[0], end_date[1], end_date[2])  # end date

    delta_days = end_date - start_date  # as timedelta

    for i in range(delta_days.days + 1):
        day = start_date + timedelta(days=i)
        dates_requested_for_data.append(str(day))

    print("Extracting data for %s days , which are %s" %(len(dates_requested_for_data), dates_requested_for_data))
    return len(dates_requested_for_data), dates_requested_for_data