from model import UserModel, DeviceModel, WeatherDataModel, DailyReportModel

class Operation:

    def __init__(self, user_name, user_data, operation_strategy):
        """take price and discount strategy"""

        self.user_data = user_data
        self.user_name = user_name
        self.operation_strategy = operation_strategy

    def operation_selection(self):

        if self.operation_strategy:
            self.operation_strategy = self.operation_strategy
            self.operation_strategy(requesting_user=self.user_name, user_data=self.user_data)
        else:
            print("Please enter some operation")

    def __repr__(self):
        ## For some reason the below code does not execute!!!
        return f'RETURN {self.operation_selection()}'

def users_read(requesting_user, user_data):

    user_coll = UserModel(requesting_user)
    user_document = user_coll.find_by_username(user_data)
    if user_document == -1:
        print(user_coll.latest_error)
    else:
        print(user_document)

def users_insert(requesting_user, user_data):
    # ADMIN - USER DB - INSERT - SUCCESS
    user_coll = UserModel(requesting_user)
    user_document = user_coll.insert_doc_into_user_coll(user_data[0], user_data[1], user_data[2])
    if user_document == -1:
        print (user_coll.latest_error)
    else:
        print (user_document)

# DEVICE DATABASE OPERATIONS
def devices_read(requesting_user, user_data):

    device_coll = DeviceModel(requesting_user)
    device_document = device_coll.find_by_device_id(user_data)
    if device_document == -1:
        print(device_coll.latest_error)
    elif device_document == "":
        print("The device might not exist or not be in the access list of ", requesting_user)
    else:
        print(device_document)

def devices_insert(requesting_user, user_data):

    device_coll = DeviceModel(requesting_user)
    device_document = device_coll.insert_doc_into_dev_coll(user_data[0], user_data[1], user_data[2], user_data[3])
    if device_document == -1:
        print(device_coll.latest_error)
    else:
        print(device_document)

def devices_update(requesting_user, user_data):

    device_coll = DeviceModel(requesting_user)
    updated_doc = device_coll.update_device(user_data[0], user_data[1], user_data[2])

    if updated_doc == -1:
        print(device_coll.latest_error)
    else:
        print(updated_doc)

def weatherdata_insert(requesting_user, user_data):

    wdata_coll = WeatherDataModel(requesting_user)
    wdata_document = wdata_coll.insert_doc_into_weatherdata_coll(user_data[0], user_data[1], user_data[2])
    if wdata_document == -1:
        print(wdata_coll.latest_error)
    else:
        print(wdata_document)

def weatherdata_read(requesting_user, user_data):

    wdata_coll = WeatherDataModel(requesting_user)
    wdata_document = wdata_coll.find_by_device_id_and_timestamp(user_data[0], user_data[1])
    if wdata_document:
        print(wdata_document)
    else:
        print("device may not be found or timestamp may be wrong")

def weatherdata_update(requesting_user, user_data):
    wdata_coll = WeatherDataModel(requesting_user)
    updated_doc = wdata_coll.update_weatherdata(user_data[0],user_data[1])
    if updated_doc == -1:
        print(wdata_coll.latest_error)
    else:
        print(updated_doc)


def create_daily_reports_coll(requesting_user):

    if requesting_user != 'admin':
        return "New collection creation is only permitted for users with admin roles!"
    else:
        requesting_user = "admin"
        report_coll = DailyReportModel(requesting_user)

    print("Building a collection, if it does not exit")
    if report_coll.REPORTS_COLLECTION not in report_coll.list_collection_names():
        report_coll.insert_data_into_daily_reports_collection()

def daily_reports_read(requesting_user, user_data):
    report_coll = DailyReportModel(requesting_user)
    reports_for_dates = report_coll.get_reports_between_dates(user_data[0], user_data[1], user_data[2])

    if reports_for_dates == -1:
        print(report_coll.latest_error)
    else:
        print(*reports_for_dates, sep="\n")

def initial_processor(user_name, user_data, user_collection_operation):
    commands = {
        # The right side function names can be anything - i have kept it same for demo purposes
        'users_read': users_read,
        'users_insert': users_insert,
        'devices_read': devices_read,
        'devices_insert': devices_insert,
        'devices_update': devices_update,
        'weatherdata_read':weatherdata_read,
        'weatherdata_insert':weatherdata_insert,
        'weatherdata_update':weatherdata_update,
        'create_daily_reports_coll':create_daily_reports_coll,
        'daily_reports_read':daily_reports_read
    }

    operation_object = Operation(user_name, user_data, commands[user_collection_operation])

    # I had to do this, but would have preferred calling operation_selection from __repr__ which did not work
    operation_object.operation_selection()
