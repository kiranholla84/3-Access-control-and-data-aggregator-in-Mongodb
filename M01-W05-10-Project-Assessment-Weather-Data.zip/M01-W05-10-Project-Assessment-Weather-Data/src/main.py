import processing_strategy
from model import UserModel, DeviceModel, WeatherDataModel, DailyReportModel
from datetime import datetime
import random

if __name__ == "__main__":


    print("\n####################### SCENARIO00 #######################\n")

    # Create new db for daily reports [fails - only admin can create the new collection daily_reports)
    user_name = "user_1"
    print(processing_strategy.create_daily_reports_coll(user_name))

    print("\n####################### SCENARIO01 #######################\n")

    # Create new db for daily reports [creates daily_reports)
    user_name = "admin"
    print(processing_strategy.create_daily_reports_coll(user_name))


    print("\n####################### SCENARIO02 #######################\n")
    # ADMIN - USER DB - READ - SUCCESS
    select_option_collection = "users"
    select_option_operation = "read"
    user_name = "admin"
    user_data = "user_1"
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO03 #######################\n")

    # ADMIN - USER DB - INSERT - SUCCESS
    select_option_collection = "users"
    select_option_operation = "insert"
    user_name = "admin"
    user_data = ('test_6'+str(random.randint(0, 20000)), 'test_3@example.com', 'default')
    processing_strategy.initial_processor(user_name, user_data,
                                                      select_option_collection + "_" + select_option_operation)

    print("\n####################### SCENARIO04 #######################\n")
    # NONADMIN - USER DB - READ - FAILURE
    select_option_collection = "users"
    select_option_operation = "read"
    user_name = "user_1"
    user_data = "user_1"
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO05 #######################\n")

    # NONADMIN - USER DB - INSERT - FAILURE
    select_option_collection = "users"
    select_option_operation = "insert"
    user_name = "user_1"
    user_data = ('test_6'+str(random.randint(0, 20000)), 'test_3@example.com', 'default')
    processing_strategy.initial_processor(user_name, user_data,
                                                      select_option_collection + "_" + select_option_operation)
    
    print("\n####################### SCENARIO06 #######################\n")

    # ADMIN - DEVICES DB - READ - SUCCESS
    select_option_collection = "devices"
    select_option_operation = "read"
    user_name = "admin"
    user_data = "DT001"
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO07 #######################\n")

    # ADMIN - DEVICES DB - INSERT - SUCCESS
    select_option_collection = "devices"
    select_option_operation = "insert"
    user_name = "admin"
    user_data = ('DT221a'+str(random.randint(0, 20000)), 'Temperature Sensor','Temperature', 'Acme')
    processing_strategy.initial_processor(user_name, user_data,
                                                      select_option_collection + "_" + select_option_operation)

    print("\n####################### SCENARIO08 #######################\n")

    # ADMIN - DEVICE DB - UPDATE - SUCCESS
    select_option_collection = "devices"
    select_option_operation = "update"
    user_name = "admin"
    user_data = ({'device_id': 'DT002'},{'desc': 'Temperature Sensor'}, {'desc': 'Temperature Sensor Updated!'})
    processing_strategy.initial_processor(user_name, user_data,
                                                      select_option_collection + "_" + select_option_operation)

    print("\n####################### SCENARIO09 #######################\n")

    # NONADMIN - DEVICES DB - READ - SUCCESS (if Device has "r" for the particular user)
    select_option_collection = "devices"
    select_option_operation = "read"
    user_name = "user_1"
    user_data = "DT001"
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO010 #######################\n")
    # NONADMIN - DEVICES DB - READ - FAILURE (if Device is not present in the access list of the particular user)
    select_option_collection = "devices"
    select_option_operation = "read"
    user_name = "user_1"
    user_data = "DT003"
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                          select_option_operation)

    print("\n####################### SCENARIO11 #######################\n")

    # NON-ADMIN - DEVICE DB - UPDATE - SUCCESS BASED ON PERMISSION (DT002 is rw for all users for easy demonstration)
    select_option_collection = "devices"
    select_option_operation = "update"
    user_name = "user_2"
    user_data = ({'device_id': 'DT002'},{'desc': 'Temperature Sensor Updated!'}, {'desc': 'Temperature Sensor'})
    processing_strategy.initial_processor(user_name, user_data,
                                                      select_option_collection + "_" + select_option_operation)
    

    print("\n####################### SCENARIO012 #######################\n")

    # NON-ADMIN - DEVICE DB - UPDATE - FAILURE BASED ON PERMISSION (DT001 is r for all users for easy demonstration)
    select_option_collection = "devices"
    select_option_operation = "update"
    user_name = "user_2"
    user_data = ({'device_id': 'DT001'},{'desc': 'Temperature Sensor)'}, {'desc': 'Temperature Sensor updated!'})
    processing_strategy.initial_processor(user_name, user_data,
                                                      select_option_collection + "_" + select_option_operation)
    
    print("\n####################### SCENARIO13 #######################\n")

    # NONADMIN - DEVICES DB - INSERT - FAILURE
    select_option_collection = "devices"
    select_option_operation = "insert"
    user_name = "user_2"
    user_data = ('DT221a'+str(random.randint(0, 20000)), 'Temperature Sensor','Temperature', 'Acme')
    processing_strategy.initial_processor(user_name, user_data,
                                                      select_option_collection + "_" + select_option_operation)
    

    print("\n####################### SCENARIO14#######################\n")

    # ADMIN - WEATHER DB - READ - SUCCESS
    select_option_collection = "weatherdata"
    select_option_operation = "read"
    user_name = "admin"
    user_data = ('DT002', datetime(2020, 12, 2, 13, 30, 0))
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO15 #######################\n")

    # ADMIN - WEATHER DB - INSERT - SUCCESS
    select_option_collection = "weatherdata"
    select_option_operation = "insert"
    user_name = "admin"
    user_data = ('DT001', 12, datetime(random.randint(2000, 2040), 12, 2, 13, random.randint(0, 59), 28))
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO16 #######################\n")

    # ADMIN - WEATHER DB - UPDATE - SUCCESS [PLEASE CHANGE OBJECT  TO ANY OBJECT ID FROM WEATHERDATA COLLECTION]
    select_option_collection = "weatherdata"
    select_option_operation = "update"
    user_name = "admin"
    user_data = ({'_id': '606960c7c4deda646d9f41fe'},{'value': 102})
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO17 #######################\n")

    select_option_collection = "weatherdata"
    select_option_operation = "read"
    user_name = "user_1"
    user_data = ('DT002', datetime(2020, 12, 2, 13, 30, 0))
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO18 #######################\n")

    # NONADMIN - WEATHER DB - READ - SUCCESS
    select_option_collection = "weatherdata"
    select_option_operation = "insert"
    user_name = "user_1"
    user_data = ('DT002', 12, datetime(random.randint(2000, 2040), 12, 2, 13, random.randint(0, 59), 28))
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO19 #######################\n")

    # NON-ADMIN - WEATHER DB - UPDATE - SUCCESS CASE (Insert any object ID belonging to device DT002 (rw))
    # [PLEASE CHANGE OBJECT ID TO ANY DT002's OBJECT ID in WEATHER DATA COLL]
    select_option_collection = "weatherdata"
    select_option_operation = "update"
    user_name = "user_1"
    user_data = ({'_id': '6069f77e8c9dcf6a81e0b921'},{'value': 202})
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)


    print("\n####################### SCENARIO20 #######################\n")

    # NONADMIN - WEATHER DB - INSERT - SUCCESS
    # if user HAS WRITE access to the appropriate device. DT001 = R, DT002 = RW for demo purposes
    select_option_collection = "weatherdata"
    select_option_operation = "insert"
    user_name = "user_1"
    user_data = ('DT002', 12, datetime(random.randint(2000, 2040), 12, 2, 13, random.randint(0, 59), 28))
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO21 #######################\n")

    # NON-ADMIN - WEATHER DB - UPDATE - FAILURE CASE

    # DT001 = R, DT002 = RW for demo purposes. So Please give ID that belongs to DT001 in weather data (no rw permission
    #  case)
    select_option_collection = "weatherdata"
    select_option_operation = "update"
    user_name = "user_1"
    user_data = ({'_id': '6069f77e8c9dcf6a81e0b895'},{'value': 302})
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)


    print("\n####################### SCENARIO22#######################\n")

    # Admin attempts to access data for 5 days for device DH001 which is not in his access list - SUCCESS as he is admin
    select_option_collection = "daily_reports"
    select_option_operation = "read"
    user_name = "admin"
    start_date = "1-12-2020"
    end_date = "5-12-2020"
    user_data = ("DT001", start_date, end_date)
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO23 #######################\n")

    # User_1 attempts to access data for 5 days for device DT001 - SUCCESS
    # Get reports from db - user1 (can get report of device which is in his access list, r or rw
    select_option_collection = "daily_reports"
    select_option_operation = "read"
    user_name = "user_1"
    start_date = "1-12-2020"
    end_date = "5-12-2020"
    user_data = ("DT001", start_date, end_date)
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)

    print("\n####################### SCENARIO24 #######################\n")
    # Get reports from db - user1 (cannot get report of device which is NOT in his access list)
    select_option_collection = "daily_reports"
    select_option_operation = "read"
    user_name = "user_1"
    start_date = "1-12-2020"
    end_date = "5-12-2020"
    user_data = ("DH001", start_date, end_date)
    processing_strategy.initial_processor(user_name, user_data, select_option_collection + "_" +
                                                      select_option_operation)