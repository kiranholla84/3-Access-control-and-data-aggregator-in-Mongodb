A) There are 24 scenarios testing out permissions for admin and non-admin role

for operations below :

 1) read, update , insert [weather, device collection]
 2) read, insert [users]
 3) insert [daily_reports_collection]
 4) get reports

B) CLient code is in main.py and client does not see concrete methods (Like a facade)

C) client code just gives data such as his preferred collection, preferred operation, his username, and data for doing the operation. 

D) Initial_processor function under processing_Strategy will "decide" which appropriate internal function (which calls function within model) to use. Strategy pattern in use here. But I could not make __repr__ function work within "Operation class" under processing_strategy.py (so not a perfect strategy pattern)

E) I did not add new users /devices/weather data in setup.py because we can test all scenarios with the existing setup.py given

F) For demo purposes, all users have access to 
DT001  as 'r' and
DT002 as 'rw'

G) output.txt available in this folder

H) scenario 16, 19, 21 need user intervention to put the right object ID (after running setup.py)

I) I added data parameter to weather data collection so aggregation using mongo db becomes easier


Extensibility/Maintainability

1) supports more devices per user with permissions

2) supports new type of devices - like preceipitation

3) suports updating any field of the weather db for the user, not restricted to just one field	

4) I assume existing devices cannot be improvised to add a new value to same device. Example, adding precipitation value to "DT001". If existing devices have multiple weather parameters,  like DT001 tracking temperature and precipitation, then a different approach is needed. 

5) For the above case of multiple weathr parameters, I would have approached using a builder pattern to create a data structure (like a hash) to have any temperature parameter (temperature, umidity, precipitation, dew point)  per timestamp per device

6) Ease of user access as he sees only what oeprations/inputs he needs to give. Interfaces in processing_strategy.py can easily be changed for any new function tomorrow without changing code (can extend existing code without changing it)

7) Strategy pattern helps in dyncmically deciding which function to use based on user inputs.

8) Please call me on 9986043327 for any queries/clarifications. I have tried my best

9) Also, request you to publish the best code (highest marks) to all so it is a learning experience